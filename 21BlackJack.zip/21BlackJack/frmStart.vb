﻿Public Class frmStart
    Dim userName As String
    Private Sub highScoresBtn_Click(sender As Object, e As EventArgs) Handles highScoresBtn.Click
        frmHighScores.Show()
        Me.Hide()
    End Sub

    Private Sub nameTextBox_TextChanged(sender As Object, e As EventArgs) Handles nameTextBox.TextChanged
        userName = nameTextBox.Text
        Globals.userName = userName
    End Sub
    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Normal
    End Sub
    Private Sub startGameBtn_Click(sender As Object, e As EventArgs) Handles startGameBtn.Click
        If userName = Nothing Then
            MsgBox("Please enter a user name")
        ElseIf userName.Length < 3 Then
            MsgBox("Enter a username greater than 3 characters")
        ElseIf userName.Length >= 11 Then
            MsgBox("Enter a username less than 11 characters")
        Else
            frmBlackJackBetting.Show()
            Me.Hide()
        End If
    End Sub
End Class