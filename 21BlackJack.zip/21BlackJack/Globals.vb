﻿Module Globals
    Public userName As String = Nothing ' declaring username as a public value
    Public ballance As Integer = 100

End Module
