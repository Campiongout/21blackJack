﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBlackJack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnDealCards = New System.Windows.Forms.Button()
        Me.lblPlayerCard = New System.Windows.Forms.Label()
        Me.lblDealerCard = New System.Windows.Forms.Label()
        Me.picPlayerCard1 = New System.Windows.Forms.PictureBox()
        Me.picDealerCard1 = New System.Windows.Forms.PictureBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.picPlayerCard2 = New System.Windows.Forms.PictureBox()
        Me.hitBtn = New System.Windows.Forms.Button()
        Me.standBtn = New System.Windows.Forms.Button()
        Me.doubleDownBtn = New System.Windows.Forms.Button()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        CType(Me.picPlayerCard1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDealerCard1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlayerCard2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDealCards
        '
        Me.btnDealCards.Location = New System.Drawing.Point(967, 428)
        Me.btnDealCards.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnDealCards.Name = "btnDealCards"
        Me.btnDealCards.Size = New System.Drawing.Size(150, 47)
        Me.btnDealCards.TabIndex = 0
        Me.btnDealCards.Text = "Deal Cards"
        Me.btnDealCards.UseVisualStyleBackColor = True
        '
        'lblPlayerCard
        '
        Me.lblPlayerCard.AutoSize = True
        Me.lblPlayerCard.Location = New System.Drawing.Point(267, 581)
        Me.lblPlayerCard.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPlayerCard.Name = "lblPlayerCard"
        Me.lblPlayerCard.Size = New System.Drawing.Size(83, 32)
        Me.lblPlayerCard.TabIndex = 1
        Me.lblPlayerCard.Text = "Label1"
        '
        'lblDealerCard
        '
        Me.lblDealerCard.AutoSize = True
        Me.lblDealerCard.Location = New System.Drawing.Point(847, 50)
        Me.lblDealerCard.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDealerCard.Name = "lblDealerCard"
        Me.lblDealerCard.Size = New System.Drawing.Size(83, 32)
        Me.lblDealerCard.TabIndex = 2
        Me.lblDealerCard.Text = "Label1"
        '
        'picPlayerCard1
        '
        Me.picPlayerCard1.Location = New System.Drawing.Point(459, 581)
        Me.picPlayerCard1.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.picPlayerCard1.Name = "picPlayerCard1"
        Me.picPlayerCard1.Size = New System.Drawing.Size(199, 230)
        Me.picPlayerCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayerCard1.TabIndex = 3
        Me.picPlayerCard1.TabStop = False
        '
        'picDealerCard1
        '
        Me.picDealerCard1.Location = New System.Drawing.Point(605, 50)
        Me.picDealerCard1.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.picDealerCard1.Name = "picDealerCard1"
        Me.picDealerCard1.Size = New System.Drawing.Size(215, 230)
        Me.picDealerCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDealerCard1.TabIndex = 4
        Me.picDealerCard1.TabStop = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 32
        Me.ListBox1.Location = New System.Drawing.Point(26, 548)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(127, 356)
        Me.ListBox1.TabIndex = 5
        '
        'picPlayerCard2
        '
        Me.picPlayerCard2.Location = New System.Drawing.Point(666, 581)
        Me.picPlayerCard2.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.picPlayerCard2.Name = "picPlayerCard2"
        Me.picPlayerCard2.Size = New System.Drawing.Size(199, 230)
        Me.picPlayerCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayerCard2.TabIndex = 6
        Me.picPlayerCard2.TabStop = False
        '
        'hitBtn
        '
        Me.hitBtn.Location = New System.Drawing.Point(508, 367)
        Me.hitBtn.Name = "hitBtn"
        Me.hitBtn.Size = New System.Drawing.Size(150, 46)
        Me.hitBtn.TabIndex = 7
        Me.hitBtn.Text = "Hit"
        Me.hitBtn.UseVisualStyleBackColor = True
        '
        'standBtn
        '
        Me.standBtn.Location = New System.Drawing.Point(664, 367)
        Me.standBtn.Name = "standBtn"
        Me.standBtn.Size = New System.Drawing.Size(150, 46)
        Me.standBtn.TabIndex = 8
        Me.standBtn.Text = "Stand"
        Me.standBtn.UseVisualStyleBackColor = True
        '
        'doubleDownBtn
        '
        Me.doubleDownBtn.Location = New System.Drawing.Point(585, 429)
        Me.doubleDownBtn.Name = "doubleDownBtn"
        Me.doubleDownBtn.Size = New System.Drawing.Size(150, 46)
        Me.doubleDownBtn.TabIndex = 9
        Me.doubleDownBtn.Text = "Double Down"
        Me.doubleDownBtn.UseVisualStyleBackColor = True
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 32
        Me.ListBox2.Location = New System.Drawing.Point(1185, 139)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(240, 324)
        Me.ListBox2.TabIndex = 10
        '
        'frmBlackJack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1486, 960)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.doubleDownBtn)
        Me.Controls.Add(Me.standBtn)
        Me.Controls.Add(Me.hitBtn)
        Me.Controls.Add(Me.picPlayerCard2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.picDealerCard1)
        Me.Controls.Add(Me.picPlayerCard1)
        Me.Controls.Add(Me.lblDealerCard)
        Me.Controls.Add(Me.lblPlayerCard)
        Me.Controls.Add(Me.btnDealCards)
        Me.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.Name = "frmBlackJack"
        Me.Text = "frmBlackJack"
        CType(Me.picPlayerCard1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDealerCard1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlayerCard2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnDealCards As Button
    Friend WithEvents lblPlayerCard As Label
    Friend WithEvents lblDealerCard As Label
    Friend WithEvents picPlayerCard1 As PictureBox
    Friend WithEvents picDealerCard1 As PictureBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents picPlayerCard2 As PictureBox
    Friend WithEvents hitBtn As Button
    Friend WithEvents standBtn As Button
    Friend WithEvents doubleDownBtn As Button
    Friend WithEvents ListBox2 As ListBox
End Class
