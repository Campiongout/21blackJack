﻿Public Class frmBlackJackBetting
    Dim bet As Integer
    Dim betString As String
    Private Sub dealCardsBtn_Click(sender As Object, e As EventArgs) Handles dealCardsBtn.Click
        frmBlackJack.Show()
        Me.Hide()
    End Sub
    Private Sub updateBallance()
        ballanceLbl.Text = ("your ballance is: " & ballance)
        betLbl.Text = bet
    End Sub
    Private Sub updateUName()
        userNameLbl.Text = ("your user name is: " & Globals.userName)
    End Sub

    Private Sub frmBlackJackBetting_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        updateUName()
        updateBallance()
    End Sub

    Private Sub updateBet()

    End Sub

    Private Sub chip1Btn_Click(sender As Object, e As EventArgs) Handles chip1Btn.Click

        ballance = ballance - 1
    End Sub

    Private Sub chip5Btn_Click(sender As Object, e As EventArgs) Handles chip5Btn.Click
        bet = bet + 5
        ballance = ballance - 5
    End Sub

    Private Sub chip25Btn_Click(sender As Object, e As EventArgs) Handles chip25Btn.Click
        bet = bet + 25
        ballance = ballance - 25
    End Sub

    Private Sub chip50Btn_Click(sender As Object, e As EventArgs) Handles chip50Btn.Click
        bet = bet + 50
        ballance = ballance - 50
    End Sub

    Private Sub chip100Btn_Click(sender As Object, e As EventArgs) Handles chip100Btn.Click
        bet = bet + 100
        ballance = ballance - 100
    End Sub

    Private Sub chip200Btn_Click(sender As Object, e As EventArgs) Handles chip200Btn.Click
        bet = bet + 200 '
        ballance = ballance - 200
    End Sub
End Class