﻿Imports System.IO

Public Class frmBlackJack
    ' variables
    Dim deck(4, 13) As String
    Dim hand(52) As String
    Dim playerCard As Integer
    Dim dealerCard(10) As String
    Dim randsuit As Integer

    'variables for picture array player
    Dim pictureArray(21) As PictureBox
    Dim xSize = 150
    Dim ySize = 300
    Dim pictureCount = 3

    Dim d As Integer = 0


    Private Sub frmBlackjackGame_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        standBtn.Hide()
        hitBtn.Hide()
        doubleDownBtn.Hide()
        generateDecks()

    End Sub
    'Private Sub initialCards()
    '    playerCard = Int(13 * Rnd()) + 1
    '    dealerCard = Int(13 * Rnd()) + 1
    '    randsuit = Int(4 * Rnd()) + 1
    '    picDealerCard1.ImageLocation = "card graphics\" & deck(randsuit, playerCard) & ".png"
    'End Sub

    Private Sub btnDealCards_Click(sender As Object, e As EventArgs) Handles btnDealCards.Click
        'For i = 0 To 1
        '    hand(i) = dealhand()
        '    ListBox1.Items.Add(hand(i))
        'Next i
        While d < 2 ' deals the initial card to the player
            hand(d) = dealhand()
            ListBox1.Items.Add(hand(d))
            d = d + 1

        End While
        'deals initial card to the dealer
        dealerCard(0) = dealhand()
        picDealerCard1.ImageLocation = "card graphics\" & dealerCard(0) & ".png"

        picPlayerCard1.ImageLocation = "card graphics\" & hand(0) & ".png"
        picPlayerCard2.ImageLocation = "card graphics\" & hand(1) & ".png"
        btnDealCards.Hide()
        hitBtn.Show()
        standBtn.Show()
        doubleDownBtn.Show()
    End Sub
    Private Sub hitBtn_Click(sender As Object, e As EventArgs) Handles hitBtn.Click
        d = d + 1
        hand(d) = dealhand() '''''cHANGED TO HAND 3
        ListBox1.Items.Add(hand(d))
        generatePicPlayer()
    End Sub
    Private Sub standBtn_Click(sender As Object, e As EventArgs) Handles standBtn.Click
        standBtn.Hide()
        hitBtn.Hide()
        doubleDownBtn.Hide()
    End Sub
    Private Sub doubleDownBtn_Click(sender As Object, e As EventArgs) Handles doubleDownBtn.Click
        hitBtn.Hide()
        standBtn.Hide()
        doubleDownBtn.Hide()
    End Sub
    Private Sub generatePicPlayer()
        ' conter will be used to set location of next picture box e.g (location = new point (xSize + (origional position *counter)
        Dim counter As Integer = 3

        Dim pictureCard As New PictureBox With {
            .ImageLocation = "card graphics\" & hand(d) & ".png",
            .Size = New Size(xSize, ySize),
            .Location = New Point(xSize, ySize),
            .Parent = Me
                 }

        pictureCard.Name = "picPlayerCard" & pictureCount
        pictureCount = pictureCount + 1
        ListBox1.Items.Add(pictureCount)


    End Sub
    Private Sub generatePicDealer()
        ' conter will be used to set location of next picture box e.g (location = new point (xSize + (origional position *counter)
        Dim counter As Integer = 3

        Dim pictureCard As New PictureBox With {
            .ImageLocation = "card graphics\" & hand(d) & ".png",
            .Size = New Size(xSize, ySize),
            .Location = New Point(xSize, ySize),
            .Parent = Me
                 }

        pictureCard.Name = "picDealerCard" & pictureCount
        pictureCount = pictureCount + 1
        ListBox1.Items.Add(pictureCount)


    End Sub
    Sub pictureArrayClick(ByVal sender As Object, ByVal e As EventArgs)
        'Not used, left over
        MsgBox("picture " & sender.name & " was clicked")
    End Sub


    Private Function dealhand() As String
        ' creates the random car delt, produces a random suit and num
        Dim num As Integer = Int(13 * Rnd()) + 1
        Dim suit As Integer = Int(4 * Rnd()) + 1

        Return deck(suit, num)

    End Function

    Private Sub generateDecks()
        'generates the deck of cars

        Dim counter As Integer = 2
        Dim firstInt = 1
        Dim suit As String
        For i = 1 To 4
            For j = 2 To 9
                Select Case i
                    Case 0 : suit = "s"
                    Case 1 : suit = "c"
                    Case 2 : suit = "d"
                    Case 3 : suit = "h"
                End Select
                deck(i, 1) = $"a{suit}"
                deck(i, 10) = $"t{suit}"
                deck(i, 11) = $"j{suit}"
                deck(i, 12) = $"q{suit}"
                deck(i, 13) = $"k{suit}"
                deck(i, j) = $"{counter}{suit}"
                counter += 1
            Next j
            counter = 2

        Next i
        For i = 0 To 3
            For j = 1 To 13
                ' ListBox1.Items.Add($"{deck(i, j)}")
            Next j
        Next i

    End Sub


End Class
