﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.startGameBtn = New System.Windows.Forms.Button()
        Me.userNameLbl = New System.Windows.Forms.Label()
        Me.highScoresBtn = New System.Windows.Forms.Button()
        Me.nameTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'startGameBtn
        '
        Me.startGameBtn.Location = New System.Drawing.Point(735, 769)
        Me.startGameBtn.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.startGameBtn.Name = "startGameBtn"
        Me.startGameBtn.Size = New System.Drawing.Size(308, 86)
        Me.startGameBtn.TabIndex = 1
        Me.startGameBtn.Text = "Play"
        Me.startGameBtn.UseVisualStyleBackColor = True
        '
        'userNameLbl
        '
        Me.userNameLbl.AutoSize = True
        Me.userNameLbl.Location = New System.Drawing.Point(962, 625)
        Me.userNameLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.userNameLbl.Name = "userNameLbl"
        Me.userNameLbl.Size = New System.Drawing.Size(0, 32)
        Me.userNameLbl.TabIndex = 2
        '
        'highScoresBtn
        '
        Me.highScoresBtn.Location = New System.Drawing.Point(1625, 900)
        Me.highScoresBtn.Margin = New System.Windows.Forms.Padding(6)
        Me.highScoresBtn.Name = "highScoresBtn"
        Me.highScoresBtn.Size = New System.Drawing.Size(139, 109)
        Me.highScoresBtn.TabIndex = 3
        Me.highScoresBtn.Text = "View high scores"
        Me.highScoresBtn.UseVisualStyleBackColor = True
        '
        'nameTextBox
        '
        Me.nameTextBox.Location = New System.Drawing.Point(786, 200)
        Me.nameTextBox.Margin = New System.Windows.Forms.Padding(6)
        Me.nameTextBox.Name = "nameTextBox"
        Me.nameTextBox.Size = New System.Drawing.Size(236, 39)
        Me.nameTextBox.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Lucida Bright", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(640, 128)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(521, 66)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Enter your name"
        '
        'frmStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1787, 1035)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.nameTextBox)
        Me.Controls.Add(Me.highScoresBtn)
        Me.Controls.Add(Me.userNameLbl)
        Me.Controls.Add(Me.startGameBtn)
        Me.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.Name = "frmStart"
        Me.Text = "frmStart"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents startGameBtn As Button
    Friend WithEvents userNameLbl As Label
    Friend WithEvents highScoresBtn As Button
    Friend WithEvents nameTextBox As TextBox
    Friend WithEvents Label1 As Label
End Class
