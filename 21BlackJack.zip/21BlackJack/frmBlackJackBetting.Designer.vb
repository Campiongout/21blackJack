﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBlackJackBetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dealCardsBtn = New System.Windows.Forms.Button()
        Me.testLabel = New System.Windows.Forms.Label()
        Me.userNameLbl = New System.Windows.Forms.Label()
        Me.chip1Btn = New System.Windows.Forms.Button()
        Me.chip5Btn = New System.Windows.Forms.Button()
        Me.chip25Btn = New System.Windows.Forms.Button()
        Me.chip50Btn = New System.Windows.Forms.Button()
        Me.chip100Btn = New System.Windows.Forms.Button()
        Me.chip200Btn = New System.Windows.Forms.Button()
        Me.ballanceLbl = New System.Windows.Forms.Label()
        Me.betLbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dealCardsBtn
        '
        Me.dealCardsBtn.Font = New System.Drawing.Font("Lucida Bright", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.dealCardsBtn.Location = New System.Drawing.Point(305, 158)
        Me.dealCardsBtn.Name = "dealCardsBtn"
        Me.dealCardsBtn.Size = New System.Drawing.Size(189, 58)
        Me.dealCardsBtn.TabIndex = 0
        Me.dealCardsBtn.Text = "Deal Cards"
        Me.dealCardsBtn.UseVisualStyleBackColor = True
        '
        'testLabel
        '
        Me.testLabel.AutoSize = True
        Me.testLabel.Location = New System.Drawing.Point(351, 302)
        Me.testLabel.Name = "testLabel"
        Me.testLabel.Size = New System.Drawing.Size(0, 15)
        Me.testLabel.TabIndex = 1
        '
        'userNameLbl
        '
        Me.userNameLbl.AutoSize = True
        Me.userNameLbl.Location = New System.Drawing.Point(19, 11)
        Me.userNameLbl.Name = "userNameLbl"
        Me.userNameLbl.Size = New System.Drawing.Size(0, 15)
        Me.userNameLbl.TabIndex = 2
        '
        'chip1Btn
        '
        Me.chip1Btn.Location = New System.Drawing.Point(19, 339)
        Me.chip1Btn.Name = "chip1Btn"
        Me.chip1Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip1Btn.TabIndex = 3
        Me.chip1Btn.Text = "Button1"
        Me.chip1Btn.UseVisualStyleBackColor = True
        '
        'chip5Btn
        '
        Me.chip5Btn.Location = New System.Drawing.Point(100, 339)
        Me.chip5Btn.Name = "chip5Btn"
        Me.chip5Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip5Btn.TabIndex = 4
        Me.chip5Btn.Text = "Button2"
        Me.chip5Btn.UseVisualStyleBackColor = True
        '
        'chip25Btn
        '
        Me.chip25Btn.AllowDrop = True
        Me.chip25Btn.Location = New System.Drawing.Point(181, 339)
        Me.chip25Btn.Name = "chip25Btn"
        Me.chip25Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip25Btn.TabIndex = 5
        Me.chip25Btn.Text = "Button3"
        Me.chip25Btn.UseVisualStyleBackColor = True
        '
        'chip50Btn
        '
        Me.chip50Btn.Location = New System.Drawing.Point(19, 381)
        Me.chip50Btn.Name = "chip50Btn"
        Me.chip50Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip50Btn.TabIndex = 6
        Me.chip50Btn.Text = "Button4"
        Me.chip50Btn.UseVisualStyleBackColor = True
        '
        'chip100Btn
        '
        Me.chip100Btn.Location = New System.Drawing.Point(100, 381)
        Me.chip100Btn.Name = "chip100Btn"
        Me.chip100Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip100Btn.TabIndex = 7
        Me.chip100Btn.Text = "Button5"
        Me.chip100Btn.UseVisualStyleBackColor = True
        '
        'chip200Btn
        '
        Me.chip200Btn.Location = New System.Drawing.Point(181, 381)
        Me.chip200Btn.Name = "chip200Btn"
        Me.chip200Btn.Size = New System.Drawing.Size(75, 23)
        Me.chip200Btn.TabIndex = 8
        Me.chip200Btn.Text = "Button6"
        Me.chip200Btn.UseVisualStyleBackColor = True
        '
        'ballanceLbl
        '
        Me.ballanceLbl.AutoSize = True
        Me.ballanceLbl.Location = New System.Drawing.Point(19, 311)
        Me.ballanceLbl.Name = "ballanceLbl"
        Me.ballanceLbl.Size = New System.Drawing.Size(51, 15)
        Me.ballanceLbl.TabIndex = 10
        Me.ballanceLbl.Text = "ballance"
        '
        'betLbl
        '
        Me.betLbl.AutoSize = True
        Me.betLbl.Location = New System.Drawing.Point(393, 237)
        Me.betLbl.Name = "betLbl"
        Me.betLbl.Size = New System.Drawing.Size(24, 15)
        Me.betLbl.TabIndex = 11
        Me.betLbl.Text = "bet"
        '
        'frmBlackJackBetting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.betLbl)
        Me.Controls.Add(Me.ballanceLbl)
        Me.Controls.Add(Me.chip200Btn)
        Me.Controls.Add(Me.chip100Btn)
        Me.Controls.Add(Me.chip50Btn)
        Me.Controls.Add(Me.chip25Btn)
        Me.Controls.Add(Me.chip5Btn)
        Me.Controls.Add(Me.chip1Btn)
        Me.Controls.Add(Me.userNameLbl)
        Me.Controls.Add(Me.testLabel)
        Me.Controls.Add(Me.dealCardsBtn)
        Me.Name = "frmBlackJackBetting"
        Me.Text = " Blackjack betting"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dealCardsBtn As Button
    Friend WithEvents testLabel As Label
    Friend WithEvents userNameLbl As Label
    Friend WithEvents chip1Btn As Button
    Friend WithEvents chip5Btn As Button
    Friend WithEvents chip25Btn As Button
    Friend WithEvents chip50Btn As Button
    Friend WithEvents chip100Btn As Button
    Friend WithEvents chip200Btn As Button
    Friend WithEvents ballanceLbl As Label
    Friend WithEvents betLbl As Label
End Class
