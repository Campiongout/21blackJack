﻿Public Class frmHighScores
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmStart.Show()
        Me.Hide()
    End Sub

    Public Structure recHighScores
        Public name As String
        Public score As Integer
    End Structure

    Dim arrHighScores(6) As recHighScores
    Dim arr(6) As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        readHighScores()
        printHighScores()
        arrHighScores(6).name = "kit"
        arrHighScores(6).score = 9
        BubbleSort()
        printHighScores()
        writeHighScores()
    End Sub

    Private Sub readHighScores()
        Dim i As Integer
        FileSystem.FileOpen(1, "hs.txt", OpenMode.Input)
        For i = 1 To 5
            FileSystem.Input(1, arrHighScores(i).name)
        Next i
        For i = 1 To 5
            FileSystem.Input(1, arrHighScores(i).score)
        Next
        FileSystem.FileClose(1)
    End Sub

    Private Sub writeHighScores()
        Dim i As Integer
        FileSystem.FileOpen(1, "hs.txt", OpenMode.Output)
        For i = 1 To 5
            FileSystem.WriteLine(1, arrHighScores(i).name)
        Next i
        For i = 1 To 5
            FileSystem.WriteLine(1, arrHighScores(i).score)
        Next
        FileSystem.FileClose(1)
    End Sub

    'Bubble sort
    Private Sub BubbleSort()
        Dim Last As Integer
        Last = 6
        Dim Swapped As Boolean
        Swapped = True
        Dim i As Integer

        While Swapped = True
            Swapped = False
            i = 1
            While i < Last
                If arrHighScores(i).score < arrHighScores(i + 1).score Then
                    Swap(arrHighScores(i), arrHighScores(i + 1))
                    Swapped = True
                End If
                i = i + 1
            End While
            Last = Last - 1
        End While
    End Sub

    Private Sub Swap(ByRef A As recHighScores, ByRef B As recHighScores)
        Dim Temp As recHighScores
        Temp = A
        A = B
        B = Temp
    End Sub

    Private Sub printHighScores()
        Dim i As Integer
        For i = 1 To 5
            hSLstBox.Items.Add(i & " " & arrHighScores(i).name & " " & arrHighScores(i).score)
        Next
        hSLstBox.Items.Add(" ")
    End Sub

    Private Sub binarySearch()
        Dim lower As Integer = 1
        Dim upper As Integer = 1
        Dim foundIt As Boolean = False
        Dim positionFound As Integer
        Do
            Dim middle As Integer
            Dim requiredName As Integer
            Dim name
            middle = Int((upper + lower) / 2)
            If requiredName = name(middle) Then
                foundIt = True
                positionFound = middle
            Else
                If requiredName < name(middle) Then
                    upper = middle - 1
                Else
                    lower = middle + 1
                End If
            End If
        Loop Until foundIt = True Or lower > upper

        If foundIt Then
            hSLstBox.Items.Add("Required name found at" & positionFound)
        Else
            hSLstBox.Items.Add("Required name" & "spaggehti" & "not found")
        End If
    End Sub
End Class